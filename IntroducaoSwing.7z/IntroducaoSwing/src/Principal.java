import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Principal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setTitle("Principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnCadastro = new JMenu("Cadastro");
		menuBar.add(mnCadastro);
		
		JMenuItem mntmUsurio = new JMenuItem("Usu\u00E1rio");
		mntmUsurio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadastroUsuario cadastroUsuario = new CadastroUsuario();
				cadastroUsuario.show();
			}
		});
		mnCadastro.add(mntmUsurio);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Tipo de Jogo");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TipoJogo tipoJogo = new TipoJogo();
				tipoJogo.show();
			}
		});
		mnCadastro.add(mntmNewMenuItem);
		
		JMenuItem mntmLanar = new JMenuItem("Lan\u00E7ar");
		mntmLanar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Lancamento lancamento = new Lancamento();
			lancamento.show();
			}
		});
		menuBar.add(mntmLanar);
		
		JMenuItem mntmSorteio = new JMenuItem("Sorteio");
		mntmSorteio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Sorteio sorteio = new Sorteio();
			sorteio.show();
			}
		});
		menuBar.add(mntmSorteio);
		
		JMenuItem menuItem = new JMenuItem("");
		menuBar.add(menuItem);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}

}
