import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaPrincipal extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			TelaPrincipal dialog = new TelaPrincipal();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public TelaPrincipal() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JButton btnBotoTeste = new JButton("Bot\u00E3o Teste");
		btnBotoTeste.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnBotoTeste.setBounds(10, 10, 167, 23);
		contentPanel.add(btnBotoTeste);
		
		textField = new JTextField();
		textField.setBounds(10, 58, 167, 20);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(10, 95, 167, 22);
		contentPanel.add(comboBox);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(10, 135, 167, 20);
		contentPanel.add(passwordField);
		
		JButton btnAbrirTelaSegundaria = new JButton("Abrir tela segundaria");
		btnAbrirTelaSegundaria.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SegundaTela telaSecundaria = new SegundaTela();
	telaSecundaria.show();
			}
		});
		btnAbrirTelaSegundaria.setBounds(227, 57, 156, 23);
		contentPanel.add(btnAbrirTelaSegundaria);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
