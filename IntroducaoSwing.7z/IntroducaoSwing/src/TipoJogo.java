import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class TipoJogo extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TipoJogo frame = new TipoJogo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TipoJogo() {
		setTitle("Cadastro de Tipo de Jogo");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 354, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDescrio = new JLabel("Descri\u00E7\u00E3o");
		lblDescrio.setBounds(48, 32, 46, 14);
		contentPane.add(lblDescrio);
		
		textField = new JTextField();
		textField.setBounds(41, 57, 265, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblQuantidadeDeNumeros = new JLabel("Quantidade de n\u00FAmeros");
		lblQuantidadeDeNumeros.setBounds(48, 94, 155, 14);
		contentPane.add(lblQuantidadeDeNumeros);
		
		textField_1 = new JTextField();
		textField_1.setBounds(41, 119, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(217, 228, 89, 23);
		contentPane.add(btnSalvar);
	}

}
