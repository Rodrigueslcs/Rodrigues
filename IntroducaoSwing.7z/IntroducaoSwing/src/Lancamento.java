import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Lancamento extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Lancamento frame = new Lancamento();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Lancamento() {
		setTitle("Lan\u00E7amento de Jogo");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 190, 308);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(44, 115, 86, 22);
		contentPane.add(comboBox);
		
		JLabel lblCdigo = new JLabel("C\u00F3digo");
		lblCdigo.setBounds(52, 26, 46, 14);
		contentPane.add(lblCdigo);
		
		textField = new JTextField();
		textField.setBounds(44, 54, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblTipoDeJogo = new JLabel("Tipo de jogo");
		lblTipoDeJogo.setBounds(52, 90, 96, 14);
		contentPane.add(lblTipoDeJogo);
		
		JLabel lblNumeroDoJogo = new JLabel("Numero do jogo");
		lblNumeroDoJogo.setBounds(52, 165, 96, 14);
		contentPane.add(lblNumeroDoJogo);
		
		textField_1 = new JTextField();
		textField_1.setBounds(44, 190, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("Gravar");
		btnNewButton.setBounds(41, 236, 89, 23);
		contentPane.add(btnNewButton);
	}

}
