import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextPane;

public class Sorteio extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sorteio frame = new Sorteio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sorteio() {
		setTitle("Sorteio");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 173, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTipoDeJogo = new JLabel("Tipo de Jogo");
		lblTipoDeJogo.setBounds(39, 24, 74, 14);
		contentPane.add(lblTipoDeJogo);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(39, 49, 87, 22);
		contentPane.add(comboBox);
		
		JButton btnSortear = new JButton("Sortear");
		btnSortear.setBounds(39, 101, 89, 23);
		contentPane.add(btnSortear);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(39, 169, 93, 54);
		contentPane.add(textPane);
		
		JLabel lblResultado = new JLabel("Resultado");
		lblResultado.setBounds(39, 151, 74, 14);
		contentPane.add(lblResultado);
	}
}
